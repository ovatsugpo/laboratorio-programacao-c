#include <string.h> 
#include <stdio.h>

int calcularpontuacao(int idade, int pressaoarterial, int tabagismo, int diabetes, int doencacardiaca, int colesterol,
float peso, float altura, int sedentarismo, int ultraprocessados, int estressecronico, int sonoinadequado, 
int sexomasc) {

int pontos = 0;
float imc = peso / (altura * altura);
if (idade >= 65) pontos += 3;
if (pressaoarterial >= 160) pontos += 3;
if (tabagismo == 1) pontos += 3;
if (diabetes == 1) pontos += 2;
if (doencacardiaca == 1) pontos += 2;
if (colesterol >= 160) pontos += 2;
if (imc >= 30) pontos += 2;
if (sedentarismo == 1) pontos += 1;
if (ultraprocessados == 1) pontos += 1;
if (estressecronico == 1) pontos += 1;
if (sonoinadequado == 1) pontos += 1;
if (sexomasc == 1) pontos +=1;
return pontos;
}
void exibirclassificacao(int pontos){
if (pontos <= 4) printf("Menor que 10%\n");
else if (pontos <= 9) printf("Entre 10% e 20% \n");
else if (pontos <=14) printf("Entre 20% e 30% \n");
else if (pontos <=18) printf("Entre 30% e 50%\n");
else printf("Acima de 50%");
}
int main(void)
{
    char nome[5][50];
    float dados[5][13];
    int quantidade;
    
    printf("================================\n");
    printf("SISTEMA DE ANÁLISE DE RISCO\n");
    printf("================================\n");
    printf("Quantidade de pacientes (1 a 5)");
    
    scanf("%d", &quantidade);
    
    for (int i = 0; i < quantidade; i++){
        printf("PACIENTE %d\n", i + 1);
        printf("nome: ");
        scanf("  %49[^\n]", nome[i]);
        
        printf("Idade: "); scanf("%d", &dados[i][0]);
        printf("Pressão sistólica(mmHg): "); scanf("%d", &dados [i][1]);
        printf("Fumante (1-Sim / 0-Não): "); scanf("%d", &dados [i][2]);
        printf("Diabetes (1-Sim / 0-Não): "); scanf("%d", &dados [i][3]);
        printf("Doença cardíaca anterior (1-Sim / 0-Não): "); scanf("%d", &dados [i][4]);
        printf("LDL (mg/dL): "); scanf("%d", &dados [i][5]);
        printf("Peso (kg): "); scanf("%f", &dados[i][6]);
        printf("Altura (m): "); scanf("%f", &dados [i][7]);
        printf("Sedentarismo (1-Sim / 0-Não): "); scanf("%d", &dados[i][8]);
        printf("Alimentação rica em ultra processados (1-Sim / 0-Não): "); scanf("%d", &dados[i][9]);
        printf("Estresse crônico (1-Sim / 0-Não): "); scanf("%d", &dados [i][10]);
        printf("Sono inadequado (1-Sim / 0-Não): "); scanf("%d", &dados [i][11]);
        printf("Sexo biológico masculino (1-Sim / 0-Não): "); scanf("%d", &dados [i][12]);
    }
    
    
    printf("================================\n");
    printf("RELÁTORIO DE RISCO\n");
    printf("================================\n");
    
    for(int i = 0; i < quantidade ; i++){
        int pontos = calcularpontuacao(
            (int)dados[i][0], (int)dados[i][1], (int)dados[i][2],
            (int)dados[i][3], (int)dados[i][4], (int)dados[i][5],
            dados[i][6], dados[i][7], (int)dados[i][8],
            (int)dados[i][9], (int)dados[i][10], (int)dados[i][11],
            (int)dados[i][12]
            );
            printf("Paciente: %s\n", nome[i]);
            printf("Classificação: ");
            exibirclassificacao(pontos);
    }
    
    
    

    return 0;
}
// FEITOR POR GUSTAVO SANTANA E VITOR NASCIMENTO
